package Q_03;

public class objaviao {
    public static void main(String[] args) {

        Aviao aviao = new Aviao(10, 900);

        aviao.mostAV();


        aviao.dimAltitude(1);


        aviao.dimVelocidade(100);

        aviao.mostAV();

    }
}
